﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RestaurantManagement.Models
{
    public class Order
    {
        public int orderId { get; set; }
        public double orderPrice { get; set; }


    }
}
